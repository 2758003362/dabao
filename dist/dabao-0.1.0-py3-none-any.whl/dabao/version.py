"""
dabao.version - 包版本信息
"""

__version__ = "0.1.0"
